import serial
import time
from enum import Enum
import threading

def include_in_docs(func):
    """标记函数或类应包含在文档中。"""
    func.__doc_include__ = True
    return func


# region Enum & Structures
@include_in_docs
class MFMCNewtonStatus(Enum):
    """
    状态码：MFMC Newton 状态枚举类型。
    该枚举类定义了与 MFMC Newton 通讯相关的各种状态及错误码。

        - NoError: 没有错误
        - NotConnected: 设备未连接
        - WSAStartup_Failed: WSAStartup 初始化失败
        - SocketCreationFailed: 创建 Socket 失败
        - InvalidServerIP: 连接服务器的 IP 非法
        - ConnectionServerFailed: 连接服务器失败
        - SendDataFailed: 发送数据失败
        - GetByteToReadFailed: 获取缓冲区数据大小失败
        - RecvDataFailed: 读取数据失败
        - RecvDataZero: 读取数据长度为 0，服务器关闭连接
        - RecvDataNotAvailable: 读取数据失败，应该返回数据但无数据返回
        - InvalidParameter: 非法参数
        - ErrorReturn: 查询返回匹配失败
        - ErrorParse: 解析返回值失败
        - IPInvalid: IP 非法
        - ConnectPortFailed: 连接串口失败
        - TargetSetError: move_close_target目标位置参数设置失败
    """

    NoError = 0  # 没有错误
    NotConnected = 1  # 设备未连接
    WSAStartup_Failed = 2  # WSAStartup初始化失败
    SocketCreationFailed = 3  # 创建Socket失败
    InvalidServerIP = 4  # 连接服务器的IP非法
    ConnectionServerFailed = 5  # 连接服务器失败
    SendDataFailed = 6  # 发送数据失败
    GetByteToReadFailed = 7  # 获取缓冲区数据大小失败
    RecvDataFailed = 8  # 读取数据失败
    RecvDataZero = 9  # 读取数据长度为0，服务器关闭连接
    RecvDataNotAvailable = 10  # 读取数据失败，应该返回数据但无数据返回
    InvalidParameter = 11  # 非法参数
    ErrorReturn = 12  # 查询返回匹配失败
    ErrorParse = 13  # 解析返回值失败
    IPInvalid = 14  # IP非法
    ConnectPortFailed = 15  # 连接串口失败
    TargetSetError = 16  # move_close_target目标位置参数设置失败

class ChannelSwitch(Enum):
    """
    控制通道开关
        - OFF ： 关闭
        - ON ： 开启
    """
    OFF = 0  # 关闭
    ON = 1  # 开启

@include_in_docs
class MCNewtonLT06:
    """
    MCNewtonLT06 参数
        - port ： 串口端口
        - baudrate: 波特率
        - timeout: 超时时间
        - device: 此设备
    """

    # region 初始化
    @include_in_docs
    def __init__(self, port, baudrate=115200, timeout=2):
        """
        初始化设备

        :param port: 串口端口
        :param baudrate: 波特率
        :param timeout: 超时时间
        """
        # 初始化锁和连接状态
        self.commandLock = threading.Lock()

        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        self.device = None
        self.connect()

    # endregion 初始化

    # region 串口通讯
    @include_in_docs
    def connect(self):
        """
        打开串口，连接设备

        :return: 状态码
        """
        # 打开串口
        try:
            self.device = serial.Serial(self.port, self.baudrate, timeout=self.timeout)
            if self.device.is_open:
                print(f"串口 {self.port} 已打开")
        except serial.SerialException as e:
            print(f"无法打开串口{self.port}: {e}")

    @include_in_docs
    def disconnect(self) -> MFMCNewtonStatus:
        """
        断开连接设备

        :return: 状态码
        """
        if self.device.is_open:
            self.device.close()
            print(f"串口 {self.port} 已关闭")
            return MFMCNewtonStatus.NoError
        return MFMCNewtonStatus.NotConnected

    def commandQueryLong(self, command: str) -> tuple:
        with self.commandLock:
            # print("commandQueryLong")

            if not self.device.is_open:
                return MFMCNewtonStatus.NotConnected, ""
            try:
                bytes_sent = self.device.write(command.encode())
                if bytes_sent == 0:
                    # print("Failed to send data.")
                    return MFMCNewtonStatus.SendDataFailed, ""

                time.sleep(0.050)  # 50ms

                # 查询串口缓冲区中的数据大小
                bytes_available = self.device.in_waiting  # 获取缓冲区中待接收字节数

                if bytes_available > 0:
                    # 接收串口的响应
                    response = self.device.read(bytes_available).decode().strip()  # 读取数据到缓冲区
                    if not response:
                        # print("No data received, or device closed the connection.")
                        return MFMCNewtonStatus.RecvDataZero, ""
                    return MFMCNewtonStatus.NoError, response  # 返回错误状态和响应数据
                else:
                    # print("No data available to read")
                    return MFMCNewtonStatus.RecvDataZero, ""
            except self.device.SerialException as e:
                print(f"Serial error: {e}")
                return MFMCNewtonStatus.SendDataFailed, ""
            except Exception as e:
                print(f"Unexpected error: {e}")
                return MFMCNewtonStatus.RecvDataFailed, ""

    def commandQueryShort(self, command: str) -> tuple:
        with self.commandLock:
            # print("commandQueryShort")

            if not self.device.is_open:
                return MFMCNewtonStatus.NotConnected, ""
            try:
                bytes_sent = self.device.write(command.encode())
                if bytes_sent == 0:
                    # print("Failed to send data.")
                    return MFMCNewtonStatus.SendDataFailed, ""

                time.sleep(0.030)  # 50ms

                # 查询串口缓冲区中的数据大小
                bytes_available = self.device.in_waiting  # 获取缓冲区中待接收字节数

                if bytes_available > 0:
                    # 接收串口的响应
                    response = self.device.read(bytes_available).decode().strip()  # 读取数据到缓冲区
                    return MFMCNewtonStatus.TargetSetError, response  # 返回错误状态和响应数据
                return MFMCNewtonStatus.NoError, ""
            except self.device.SerialException as e:
                print(f"Serial error: {e}")
                return MFMCNewtonStatus.SendDataFailed, ""
            except Exception as e:
                print(f"Unexpected error: {e}")
                return MFMCNewtonStatus.RecvDataFailed, ""

    def commandQueryReadLine(self, command: str) -> tuple:
        with self.commandLock:
            # print("commandQueryReadLine")

            if not self.device.is_open:
                return MFMCNewtonStatus.NotConnected, ""
            try:
                self.device.flush()
                bytes_sent = self.device.write(command.encode())
                if bytes_sent == 0:
                    # print("Failed to send data.")
                    return MFMCNewtonStatus.SendDataFailed, ""

                time.sleep(0.030)  # 50ms

                # 查询串口缓冲区中的数据大小
                bytes_available = self.device.in_waiting  # 获取缓冲区中待接收字节数

                if bytes_available > 0:
                    # 接收串口的响应
                    response = self.readLine().decode().strip()  # 读取数据到缓冲区
                    if not response:
                        # print("No data received, or device closed the connection.")
                        return MFMCNewtonStatus.RecvDataZero, ""
                    self.device.flush() # 离开之前清理串口缓冲区
                    return MFMCNewtonStatus.NoError, response  # 返回错误状态和响应数据
                else:
                    # print("No data available to read")
                    return MFMCNewtonStatus.RecvDataZero, ""
            except self.device.SerialException as e:
                print(f"Serial error: {e}")
                return MFMCNewtonStatus.SendDataFailed, ""
            except Exception as e:
                print(f"Unexpected error: {e}")
                return MFMCNewtonStatus.RecvDataFailed, ""

    def readLine(self):
        received_data = b''
        while True:
            byte = self.device.read(1)
            if not byte:
                break
            received_data += byte
            if b']' in received_data:
                break
        return received_data

    def commandSet(self, command) -> MFMCNewtonStatus:
        with self.commandLock:
            response = ""
            # print("commandSet")
            if not self.device.is_open:
                return MFMCNewtonStatus.NotConnected
            try:
                self.device.flush()
                bytes_sent = self.device.write(command.encode())
                if bytes_sent == 0:
                    # print("Failed to send data.")
                    return MFMCNewtonStatus.SendDataFailed
                time.sleep(0.030)  # 30ms

                # 查询串口缓冲区中的数据大小
                bytes_available = self.device.in_waiting  # 获取缓冲区中待接收字节数
                if bytes_available > 0:
                    # 接收串口的响应
                    response = self.device.readline().decode().strip()  # 读取数据到缓冲区
                    # print(f"error response:{response}")
            except self.device.SerialException as e:
                print(f"Serial error: {e}")
                return MFMCNewtonStatus.SendDataFailed
            except Exception as e:
                print(f"Unexpected error: {e}")
                return MFMCNewtonStatus.RecvDataFailed
            return MFMCNewtonStatus.NoError

    # endregion 串口通讯

    # region 指令控制台
    @include_in_docs
    def commandConsole(self, command: str) -> tuple:
        """
        指令控制台

        :param command: 需要发送的指令
        :return: 状态码,返回的指令
        """
        return self.commandQueryLong(command)

    # endregion 指令控制台

    # region 硬件查询
    @include_in_docs
    def hard_idn(self)->tuple:
        """
        返回控制器版本号

        :return: 状态码,版本号
        """
        status, response = self.commandQueryReadLine(f"[*IDN?]")
        if status != MFMCNewtonStatus.NoError:
            return status, ""
        response = response.split("[")[1].split("]")[0]
        return MFMCNewtonStatus.NoError, response
    # endregion 硬件查询

    # region 参数设置
    @include_in_docs
    def set_cap(self, cap: int) -> MFMCNewtonStatus:
        """
        修改控制设备电容值 cap，构建[cap:xxxnF]命令

        :param cap: 设置的电容值，单位为nF
        :return: 状态码
        """

        # 构建基础命令字符串
        command_string = "[cap:{:0>3d}nF]".format(cap)
        # 调用 commandSet 发送命令
        return self.commandSet(command_string)

    @include_in_docs
    def set_volt(self, volt: int) -> MFMCNewtonStatus:
        """
        修改控制设备电压值 volt，构建[volt:+xxxV]命令

        :param volt: 设置的电压值，单位为V
        :return: 状态码
        """

        # 构建基础命令字符串
        command_string = "[volt:+{:0>3d}V]".format(volt)
        # 调用 commandSet 发送命令
        return self.commandSet(command_string)

    @include_in_docs
    def set_freq(self, freq: int) -> MFMCNewtonStatus:
        """
        修改控制设备频率值 freq，构建[freq:xxxxHz]命令

        :param freq: 设置的频率，单位为Hz
        :return: 状态码
        """

        # 构建基础命令字符串
        command_string = "[freq:{:0>5d}Hz]".format(freq)
        # 调用 commandSet 发送命令
        return self.commandSet(command_string)
    # endregion 参数设置

    # region 步进模式
    @include_in_docs
    def move_slid(self) -> MFMCNewtonStatus:
        """
        设置步进方式为slide模式，构建[-slid-]命令

        :return: 状态码
        """

        # 构建基础命令字符串
        command_string = f"[-slid-]"
        # 调用 commandSet 发送命令
        return self.commandSet(command_string)

    @include_in_docs
    def move_step(self) -> MFMCNewtonStatus:
        """
        设置步进方式为step模式，构建[-step-]命令

        :return: 状态码
        """

        # 构建基础命令字符串
        command_string = f"[-step-]"
        # 调用 commandSet 发送命令
        return self.commandSet(command_string)
    # endregion 步进模式

    # region 通道开关
    @include_in_docs
    def channel_set(self,channel:int, channelswitch:ChannelSwitch) -> MFMCNewtonStatus:
        """
        设置通道打开和关闭，构建[chx:x]命令

        :channel:通道号
        :channelswitch:开关模式
        :return: 状态码
        """

        if channel < 1 or channel > 6:
            print('channel参数错误')
            return MFMCNewtonStatus.InvalidParameter
        # 构建基础命令字符串
        command_string = f"[ch{channel}:{channelswitch.value}]"
        # 调用 commandSet 发送命令
        return self.commandSet(command_string)

    @include_in_docs
    def channel1_on(self) -> MFMCNewtonStatus:
        """
        设置通道1打开，构建[ch1:1]命令

        :return: 状态码
        """
        return self.channel_set(1,ChannelSwitch.ON)

    @include_in_docs
    def channel1_off(self) -> MFMCNewtonStatus:
        """
        设置通道1关闭，构建[ch1:0]命令

        :return: 状态码
        """
        return self.channel_set(1,ChannelSwitch.OFF)

    @include_in_docs
    def channel2_on(self) -> MFMCNewtonStatus:
        """
        设置通道2打开，构建[ch2:1]命令

        :return: 状态码
        """
        return self.channel_set(2,ChannelSwitch.ON)

    @include_in_docs
    def channel2_off(self) -> MFMCNewtonStatus:
        """
        设置通道2关闭，构建[ch2:0]命令

        :return: 状态码
        """
        return self.channel_set(2,ChannelSwitch.OFF)

    @include_in_docs
    def channel3_on(self) -> MFMCNewtonStatus:
        """
        设置通道3打开，构建[ch3:1]命令

        :return: 状态码
        """
        return self.channel_set(3,ChannelSwitch.ON)

    @include_in_docs
    def channel3_off(self) -> MFMCNewtonStatus:
        """
        设置通道3关闭，构建[ch3:0]命令

        :return: 状态码
        """
        return self.channel_set(3,ChannelSwitch.OFF)

    @include_in_docs
    def channel4_on(self) -> MFMCNewtonStatus:
        """
        设置通道4打开，构建[ch4:1]命令

        :return: 状态码
        """
        return self.channel_set(4,ChannelSwitch.ON)

    @include_in_docs
    def channel4_off(self) -> MFMCNewtonStatus:
        """
        设置通道4关闭，构建[ch4:0]命令

        :return: 状态码
        """
        return self.channel_set(4,ChannelSwitch.OFF)

    @include_in_docs
    def channel5_on(self) -> MFMCNewtonStatus:
        """
        设置通道5打开，构建[ch5:1]命令

        :return: 状态码
        """
        return self.channel_set(5,ChannelSwitch.ON)

    @include_in_docs
    def channel5_off(self) -> MFMCNewtonStatus:
        """
        设置通道5关闭，构建[ch5:0]命令

        :return: 状态码
        """
        return self.channel_set(5,ChannelSwitch.OFF)

    @include_in_docs
    def channel6_on(self) -> MFMCNewtonStatus:
        """
        设置通道6打开，构建[ch6:1]命令

        :return: 状态码
        """
        return self.channel_set(6,ChannelSwitch.ON)

    @include_in_docs
    def channel6_off(self) -> MFMCNewtonStatus:
        """
        设置通道6关闭，构建[ch6:0]命令

        :return: 状态码
        """
        return self.channel_set(6,ChannelSwitch.OFF)
    # endregion 通道开关

    # region 运动控制
    @include_in_docs
    def move_open_pulse_positive(self, pulse: int) -> MFMCNewtonStatus:
        """
        设置脉冲数pulse并开始正向运动，构建[+:pulse]命令

        :param pulse: 正向运动的脉冲数
        :return: 状态码
        """

        command_string = "[+:{:0>6d}]".format(pulse)

        return self.commandSet(command_string)

    @include_in_docs
    def move_open_pulse_negative(self, pulse: int) -> MFMCNewtonStatus:
        """
        设置脉冲数pulse并开始负向运动，构建[-:pulse]命令

        :param pulse: 负向运动的脉冲数
        :return: 状态码
        """

        command_string = "[-:{:0>6d}]".format(pulse)

        return self.commandSet(command_string)

    @include_in_docs
    def move_open_positive_until_stop(self) -> MFMCNewtonStatus:
        """
        正方向持续运动直至收到停止命令，构建[+:000000]命令

        :return: 状态码
        """

        command_string = f"[+:000000]"

        return self.commandSet(command_string)

    @include_in_docs
    def move_open_negative_until_stop(self) -> MFMCNewtonStatus:
        """
        反方向持续运动直至收到停止命令，构建[-:000000]命令

        :return: 状态码
        """

        command_string = f"[-:000000]"

        return self.commandSet(command_string)

    @include_in_docs
    def move_close_target(self, target: float) -> tuple:
        """
        运动至target mm位置处，构建[movetarget:target]命令

        :param target: 运动的目标位置
        :return: 状态码, 闭环运动位置参数设置失败返回值
        """

        command_string = f"[movetarget:{target}]"

        return self.commandQueryShort(command_string)

    @include_in_docs
    def move_stop(self) -> MFMCNewtonStatus:
        """
        停止运动，构建[stop]命令

        :return: 状态码
        """

        command_string = f"[stop]"

        return self.commandSet(command_string)
    # endregion 运动控制

    # region 参数查询
    @include_in_docs
    def read_pulse(self) -> tuple:
        """
        查询剩余脉冲数，构建[read:pulse?]命令

        :return: 状态码和当前剩余脉冲数
        """
        pulse = 0
        status, response = self.commandQueryReadLine(f"[read:pulse?]")
        if status != MFMCNewtonStatus.NoError:
            return status, pulse
        try:
            parts = response.split("[")[1].split("]")[0]
            pulse = int(parts)
            return MFMCNewtonStatus.NoError, pulse
        except ValueError:
            return MFMCNewtonStatus.ErrorParse, pulse

    @include_in_docs
    def check_voltage(self) -> tuple:
        """
        查询位置传感器电压值，构建[v?]命令

        :return: 状态码和当前位置传感器电压值
        """
        voltage = 0
        status, response = self.commandQueryReadLine(f"[v?]")
        if status != MFMCNewtonStatus.NoError:
            return status, voltage
        try:
            parts = response.split("[+")[1].split("v]")[0]
            voltage = float(parts)
            return MFMCNewtonStatus.NoError, voltage
        except ValueError:
            return MFMCNewtonStatus.ErrorParse, voltage

    @include_in_docs
    def check_position(self) -> tuple:
        """
        查询当前位置，单位为mm(°)，构建[check:pos?]命令

        :return: 状态码和当前位置
        """
        position = 0
        status, response = self.commandQueryReadLine(f"[check:pos?]")
        if status != MFMCNewtonStatus.NoError:
            return status, position
        try:
            parts = response.split("[pos:")[1].split("]")[0]
            position = float(parts)
            return MFMCNewtonStatus.NoError, position
        except ValueError:
            return MFMCNewtonStatus.ErrorParse, position
    # endregion 参数查询

    # region 显示单位
    @include_in_docs
    def change_units_angle(self) -> MFMCNewtonStatus:
        """
        切换屏幕显示位置单位为 °，构建[changeunits:angle]命令

        :return: 状态码
        """

        command_string = f"[changeunits:angle]"

        return self.commandSet(command_string)

    @include_in_docs
    def change_units_mm(self) -> MFMCNewtonStatus:
        """
        切换屏幕显示位置单位为 mm，构建[changeunits:mm]命令

        :return: 状态码
        """

        command_string = f"[changeunits:mm]"

        return self.commandSet(command_string)
    # endregion 显示单位

    # region 通讯模式
    @include_in_docs
    def change_tcp(self) -> MFMCNewtonStatus:
        """
        切换通讯为网口模式，构建[change:tcp]命令

        :return: 状态码
        """

        command_string = f"[change:tcp]"

        return self.commandSet(command_string)

    @include_in_docs
    def change_usart(self) -> MFMCNewtonStatus:
        """
        切换通讯为串口模式，构建[change:usart]命令

        :return: 状态码
        """

        command_string = f"[change:usart]"

        return self.commandSet(command_string)
    # endregion 通讯模式

