from NewtonLT06.MCNewtonLT06 import *

PACKAGE_VERSION = "1.0.0"